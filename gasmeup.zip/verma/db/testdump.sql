DROP TABLE IF EXISTS test.Student;

CREATE TABLE ethgasprice (
	Time_in_second INT PRIMARY KEY,
	fast INT,
	average INT,
	low INT,
	blocknum INT
);

INSERT INTO ethgasprice (Time_in_second, fast, average, low, blocknum) VALUES(1,22,23,25,2556);

ALTER USER 'root' IDENTIFIED WITH mysql_native_password BY 'password';

flush privileges;
