
 // ###################################
 //
 // Project: GasMeUp
 // Author: Reilly Xu
 // Date: Feb. 2022.
 // Project goal: To retrieve Ethereum's transaction gas price via public source, then store the price info in local database 
 //				 and make the info available on local web server, via endpoints.
 // Usage: First need to start the local web server by running this .js script at command line >"node GasMeUp.js"
 //		   Then go to the web brower, use the first endpoint (http://localhost:3000/gas) to retrieve the gas price info
 //				(fast, average, low and blockNum) at present time.  
 //		   After the server being running for a while, use the second endpoint http://localhost:3000/average?fromTime=&toTime= 
 //				to retrieve the average gas price between two time points fromTime and toTime.  
 // Note:  All gas prices returned are in the unit of 0.1gwei, which is 10^(-10) of 1 ETH.			
 // 	
 // ####################################
 
 
 // ==============================
 // Start a local web server 
 // ==============================
 
	//use the application off of express package
	var express = require("express");
	
	var app = express();
	
	const port = process.env.PORT || 3000;
	
	//start the server
	const server = app.listen(port);
	
	//time-out in 5 minutes for all requests to the server 
	server.timeout = 1000 * 60 * 5; 
	
	// Starting time of the server
	var StartingTimeInSeconds = Math.floor(Date.now()/1000);


 // ========================================
 // Create a connection to MySQL database  
 // ========================================

	const mysql = require('mysql');
	
	//Fixing Node Mysql "Error: Cannot enqueue Handshake after invoking quit
	//Because one may lose the connection to a MySQL server due to network problems, the server timing out, or the server crashing. 
	//All of these events are considered fatal errors, and will have the err.code ='PROTOCOL_CONNECTION_LOST'
	//The function below will reconnect to the server if it lost the connection
	/*function initializeConnection(config) {

		function addDisconnectHandler(connection) {
			connection.on("error", function (error) {
				if (error instanceof Error) {
					if (error.code === "PROTOCOL_CONNECTION_LOST") {
						console.error(error.stack);
						console.log("Lost connection. Reconnecting...");
	
						initializeConnection(connection.config);
					} else if (error.fatal) {
						throw error;
					}
				}
			});
		}
	
		var connection = mysql.createConnection(config);
	
		// Add handlers.
		addDisconnectHandler(connection);
	
		connection.connect();
		return connection;
	}
	*/
	// Create a connection to the mySQL database, with auto reconnecting ability
	/*
	var con = initializeConnection({
		host: 'localhost',
		user: 'root',
		password: 'password',
		database: 'test'
	});
*/

const con = mysql.createPool({
  connectionLimit: 10,
  host: process.env.MYSQL_HOST || 'localhost',
  user: process.env.MYSQL_USER || 'root',
  password: process.env.MYSQL_PASSWORD || 'password',
  database: process.env.MYSQL_DATABASE || 'test'
});

 // ==============================================
 // Define the endpoints actions of the web server  
 // ==============================================


	//ethgasstation url, the source of our data	
	const url = 'https://ethgasstation.info/api/ethgasAPI.json?' ;
	
	//define the route for "/" to readme
	app.get("/", function (request, response){
		response.sendFile(__dirname+"/READ.me");
	});
	
	
	// endpoint1 "/gas" 
	// to get gas price info from gasstation URL and returns selected info to users, the numbers retrieved are in unit of 0.1gwei
	//--------------------------------------------
	app.get("/gas", function (request, response){

		var req = require('request');

		req(url, function (error, res, body) {
			if (!error && res.statusCode == 200) {
				var importedJSON = JSON.parse(body);
				response.send("{\"error\": false, \"message\": {\"fast\": " + importedJSON.fastest + ", \"average\": " + 
						importedJSON.fast + ", \"low\": "+ importedJSON.safeLow + ", \"blockNum\": "+ importedJSON.blockNum + "}}");
			}
			else{
				response.send("{\"error\": true, \"message\":  "+ error.message + "}");
			} 
		});
	
	});
	
	// endpoint2 "/average?fromTime=&toTime=""
	// to get the average gas price from MySQL database for the time period between fromTime and toTime
	// fromTime can't be earlier than server starting time; toTime can't be more than 10 mins in the future.
	//------------------------------------------------------------
	app.get("/average", function (request, response){

		var Inputfromtime = request.query.fromTime;
		var Inputtotime = request.query.toTime;
		const nextTenMins = Math.floor(Date.now()/1000) + 60 * 10 ;  // 10 mins in the future
		var myQuery = '';
	
			// fromTime can't be earlier than server starting time; toTime can't be more than 10 mins in the future.
			if ((Inputfromtime < StartingTimeInSeconds ) || ( Inputtotime > nextTenMins ) ) {
				response.send("{\"error\": true, \"message\": fromTime and toTime should be between " + 
							StartingTimeInSeconds + " and " + nextTenMins + " }");
			} else {
				myQuery = 'SELECT avg(average) as avg FROM ethgasprice where time_in_second between '+ 
									Inputfromtime + ' and ' + Inputtotime ;
				con.query( myQuery, (err,rows) => {
					if(err) throw err;
					response.send("{\"error\": false, \"message\": { \"average\": "+ rows[0].avg + ", \"fromTime\": " 
							+ Inputfromtime + ", \"toTime\": "+ Inputtotime + " }}");
				});
			}
	});
 
 
 // =========================================================================================
 // Kick off the loop to periodically retrieve the gasprice info and insert to MySQL database 
 // =========================================================================================

	function sleep(milliseconds) {
		const date = Date.now();
		let currentDate = null;
		do {
			currentDate = Date.now();
		} while (currentDate - date < milliseconds);
	}
	
	const req2 = require('request-promise') ; // for async purpose
	var timeinsecond = Math.floor(Date.now()/1000) ;
	const EndTime = timeinsecond + 60*60 ;  // 60 minutes, the run time limit for the loop. To save db storage.
	var sql2 = '';
	var importedJSON = '';
	
	// asynchronous function to accomodate the waiting inside the loop of querying URL and inserting data into database. 
	
	async function loop_insert() {
		// loop for one hour while requesting to URL every 5 seconds 	 
		while ( timeinsecond < EndTime ) {  
			try {
				await req2(url, function (error, res, body) {
					if (!error && res.statusCode == 200) {
						importedJSON = JSON.parse(body);
						timeinsecond = Math.floor(Date.now()/1000) ;
						sql2 = "INSERT INTO ethgasprice (time_in_second, fast, average, low, blocknum) VALUES (" + 
										timeinsecond + "," + importedJSON.fastest + "," + importedJSON.fast + "," + 
										importedJSON.safeLow + "," + importedJSON.blockNum + ")" ;
						console.log(sql2); // Print the Insert Statement to the console
						con.query(sql2, function(err,rows) {						
							if(err) { //throw error
								return console.error('error: ' + err.message);
							}
						});
					} 
				});
			} catch (e) {
				console.error(e)
			}  
			sleep(5000) ; // wait 5 seconds before making the next request
		}
	}
	
	// call actual function to request and insert continously.  
	loop_insert();
  
	console.log("Server http://localhost:3000 starts ..");
	console.log("Starting UnixTimeStamp: ", StartingTimeInSeconds);
	console.log("Start inserting into database ... and it is going to stop in 60 minutes to save DB space....");
	
 

